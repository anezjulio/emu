#!/bin/ksh

echo "Levantando Simulador Banelco"
/usr/java6_64/jre/bin/java -cp 'lib/sim-banelco.jar:lib/log4j-1.2.13.jar:lib/commons-beanutils-1.8.3.jar:lib/commons-digester3-3.2-with-deps.jar:lib/commons-logging-1.1.1.jar:lib/commons-io-1.4.jar' -Dserver.iso.port=4003 -Dserver.baseConfDir=$PWD/cfg/ certant.simbanelco.server.LauncherISO echo "ISO DEV" &